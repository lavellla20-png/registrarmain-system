﻿import { FormEvent, useEffect, useMemo, useState } from 'react'

import { api, getErrorMessage } from '../api'
import { ContinuingIcon, SearchIcon } from '../components/Icons'

type Program = {
  id: number
  code: string
  name: string
  program_adviser: string
  school_dean: string
}

type Section = {
  id: number
  name: string
  program: number
  year_level: number
  semester: number
}

type Subject = {
  id: number
  code: string
  title: string
}

type AcademicTerm = {
  id: number
  year_label: string
  semester: number
  is_active: boolean
}

type ProspectusEntry = {
  id: number
  program: number
  subject: number
  year_level: number
  semester: number
  academic_year: string
  section: number | null
  prerequisite: number | null
}

type StudentLoad = {
  id: number
  status: string
  term_id: number
  term_label: string
  subject_id: number
  subject_code: string
  subject_title: string
}

type StudentDetail = {
  id: number
  student_id: string
  last_name: string
  first_name: string
  middle_name: string
  extension_name: string
  program: number
  year_level: number
  academic_year: string
  semester: number | null
  section: number | null
  adviser_name?: string
  dean_name?: string
  adviser_approval_status?: string
  dean_approval_status?: string
  subject_load_schedule?: string
  loads: StudentLoad[]
}

type StudentSummary = {
  id: number
  student_id: string
  first_name: string
  last_name: string
  middle_name: string
}

const buildAcademicYearOptions = () => {
  const currentYear = new Date().getFullYear()
  return Array.from({ length: 21 }, (_, i) => {
    const start = currentYear - 10 + i
    return `${start}-${start + 1}`
  })
}

export function ContinuingPage() {
  const [searchId, setSearchId] = useState('')
  const [student, setStudent] = useState<StudentDetail | null>(null)

  const [allStudents, setAllStudents] = useState<StudentDetail[]>([])
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [programs, setPrograms] = useState<Program[]>([])
  const [sections, setSections] = useState<Section[]>([])
  const [subjects, setSubjects] = useState<Subject[]>([])
  const [prospectusEntries, setProspectusEntries] = useState<ProspectusEntry[]>([])
  const [terms, setTerms] = useState<AcademicTerm[]>([])

  const [selectedProgram, setSelectedProgram] = useState('')
  const [selectedYearLevel, setSelectedYearLevel] = useState('1')
  const [selectedAcademicYear, setSelectedAcademicYear] = useState('')
  const [selectedSemester, setSelectedSemester] = useState('1')
  const [selectedSection, setSelectedSection] = useState('')

  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  const academicYearOptions = useMemo(buildAcademicYearOptions, [])

  const loadReferenceData = async () => {
    const [programResp, sectionResp, subjectResp, prospectusResp, termResp, studentsResp] = await Promise.all([
      api.get<Program[]>('/programs/'),
      api.get<Section[]>('/sections/'),
      api.get<Subject[]>('/subjects/'),
      api.get<ProspectusEntry[]>('/prospectus/'),
      api.get<AcademicTerm[]>('/terms/'),
      api.get<StudentDetail[]>('/students/'), // Load detailed student data to check continuing status
    ])
    setPrograms(programResp.data)
    setSections(sectionResp.data)
    setSubjects(subjectResp.data)
    setProspectusEntries(prospectusResp.data)
    setTerms(termResp.data)
    
    // Filter to show only students who have undergone continuing process
    // Exclude 1st Year - 1st Semester students and only show actual continuing students
    console.log('All students data:', studentsResp.data)
    
    const continuingStudents = studentsResp.data.filter(student => {
      // Exclude 1st Year - 1st Semester students
      const isFirstYearFirstSem = student.year_level === 1 && student.semester === 1
      
      // Only show students who are NOT in 1st Year - 1st Semester
      // These are the actual continuing students
      const isContinuingStudent = !isFirstYearFirstSem
      
      console.log(`Student ${student.student_id} (${student.last_name}, ${student.first_name}):`, {
        year_level: student.year_level,
        semester: student.semester,
        isFirstYearFirstSem,
        isContinuingStudent,
        adviser_status: student.adviser_approval_status,
        dean_status: student.dean_approval_status,
        schedule: student.subject_load_schedule
      })
      
      return isContinuingStudent
    })
    
    console.log('Filtered continuing students:', continuingStudents)
    setAllStudents(continuingStudents)
  }

  useEffect(() => {
    loadReferenceData().catch((err) => setError(getErrorMessage(err)))
  }, [])

  const searchStudent = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setError('')
    setSuccess('')

    try {
      const response = await api.get<StudentDetail>(`/students/${searchId}/`)
      const found = response.data
      setStudent(found)

      setSelectedProgram(String(found.program))
      setSelectedYearLevel(String(found.year_level))
      setSelectedAcademicYear(found.academic_year || '')
      setSelectedSemester(String(found.semester ?? 1))
      setSelectedSection(found.section ? String(found.section) : '')

      setSuccess('Student found.')
    } catch (err) {
      setStudent(null)
      setError(getErrorMessage(err))
    }
  }

  const selectedProgramData = programs.find((program) => String(program.id) === selectedProgram)
  const selectedSectionData = sections.find((section) => String(section.id) === selectedSection)
  const resolvedAdviserName = selectedProgramData?.program_adviser || student?.adviser_name || ''
  const resolvedDeanName = selectedProgramData?.school_dean || student?.dean_name || ''

  const filteredSections = selectedProgram
    ? sections.filter(
        (section) =>
          String(section.program) === selectedProgram &&
          String(section.year_level) === selectedYearLevel &&
          String(section.semester) === selectedSemester,
      )
    : sections

  const subjectMap = useMemo(() => {
    const map = new Map<number, Subject>()
    subjects.forEach((subject) => map.set(subject.id, subject))
    return map
  }, [subjects])

  const scheduleFromCurrentLoads = useMemo(() => {
    if (!student || !selectedAcademicYear || !selectedSemester) return [] as Array<{ code: string; title: string }>
    const semNeedle = `Sem ${selectedSemester}`
    return student.loads
      .filter((load) => load.term_label.includes(selectedAcademicYear) && load.term_label.includes(semNeedle))
      .map((load) => ({ code: load.subject_code, title: load.subject_title }))
  }, [student, selectedAcademicYear, selectedSemester])

  const scheduleFromProspectus = useMemo(() => {
    if (!selectedProgram || !selectedYearLevel || !selectedSemester || !selectedAcademicYear || !selectedSection) {
      return [] as Array<{ code: string; title: string }>
    }
    const exact = prospectusEntries
      .filter(
        (entry) =>
          String(entry.program) === selectedProgram &&
          String(entry.year_level) === selectedYearLevel &&
          String(entry.semester) === selectedSemester &&
          entry.academic_year === selectedAcademicYear &&
          String(entry.section ?? '') === selectedSection,
      )
    const resolvedEntries =
      exact.length > 0
        ? exact
        : prospectusEntries.filter(
            (entry) =>
              String(entry.program) === selectedProgram &&
              String(entry.year_level) === selectedYearLevel &&
              String(entry.semester) === selectedSemester &&
              entry.academic_year === '' &&
              entry.section === null,
          )
    return resolvedEntries
      .map((entry) => {
        const subject = subjectMap.get(entry.subject)
        return {
          code: subject?.code ?? String(entry.subject),
          title: subject?.title ?? 'Unknown Subject',
        }
      })
  }, [prospectusEntries, selectedProgram, selectedYearLevel, selectedSemester, selectedAcademicYear, selectedSection, subjectMap])

  const scheduleRows = scheduleFromCurrentLoads.length ? scheduleFromCurrentLoads : scheduleFromProspectus

  const saveChanges = async () => {
    if (!student) return
    setError('')
    setSuccess('')
    try {
      await api.patch(`/students/${student.student_id}/`, {
        program: Number(selectedProgram),
        year_level: Number(selectedYearLevel),
        academic_year: selectedAcademicYear,
        semester: Number(selectedSemester),
        section: selectedSection ? Number(selectedSection) : null,
        adviser_name: resolvedAdviserName,
        dean_name: resolvedDeanName,
      })
      const refreshed = await api.get<StudentDetail>(`/students/${student.student_id}/`)
      setStudent(refreshed.data)
      setSuccess('Student changes saved.')
    } catch (err) {
      setError(getErrorMessage(err))
    }
  }

  const promoteStudent = async () => {
    if (!student) return
    setError('')
    setSuccess('')

    if (!selectedYearLevel || !selectedProgram || !selectedAcademicYear || !selectedSemester || !selectedSection) {
      setError('Please fill all target academic details.')
      return
    }

    try {
      // Find matching AcademicTerm
      const matchedTerm = terms.find(
        (term) => term.year_label === selectedAcademicYear && Number(term.semester) === Number(selectedSemester)
      )
      if (!matchedTerm) {
        setError('No matching Academic Term found. Create/activate term first in Admin.')
        return
      }

      // Create new AcademicHistory record for the promotion
      await api.post('/academic-history/', {
        student: student.id,
        academic_year: selectedAcademicYear,
        year_level: Number(selectedYearLevel),
        semester: Number(selectedSemester),
        program: Number(selectedProgram),
        section: Number(selectedSection),
        status: 'ongoing',
        start_date: new Date().toISOString().split('T')[0],  // Today's date
      })

      // Update student's current info (but preserve history)
      await api.patch(`/students/${student.student_id}/`, {
        year_level: Number(selectedYearLevel),
        semester: Number(selectedSemester),
        academic_year: selectedAcademicYear,
        program: Number(selectedProgram),
        section: Number(selectedSection),
      })

      // Trigger auto-load for new subjects
      await api.post('/continuing/promote/', {
        student_ids: [student.student_id],
        target_year_level: Number(selectedYearLevel),
        term_id: matchedTerm.id,
      })

      const refreshed = await api.get<StudentDetail>(`/students/${student.student_id}/`)
      setStudent(refreshed.data)
      setSuccess('Student promoted and new academic history record created.')
    } catch (err) {
      setError(getErrorMessage(err))
    }
  }

  const approveAndFinalizeSchedule = async () => {
    if (!student) return
    setError('')
    setSuccess('')
    try {
      const scheduleText = scheduleRows.map((row) => `${row.code} - ${row.title}`).join('\n')
      await api.patch(`/students/${student.student_id}/`, {
        adviser_name: resolvedAdviserName,
        adviser_approval_status: 'approved',
        dean_name: resolvedDeanName,
        dean_approval_status: 'approved',
        subject_load_schedule: scheduleText,
        academic_year: selectedAcademicYear,
        semester: Number(selectedSemester),
      })
      const refreshed = await api.get<StudentDetail>(`/students/${student.student_id}/`)
      setStudent(refreshed.data)
      setSuccess('Schedule approved and finalized.')
    } catch (err) {
      setError(getErrorMessage(err))
    }
  }

  const openModal = () => {
    setIsModalOpen(true)
    setStudent(null)
    setSearchId('')
    setSuccess('')
    setError('')
  }

  const closeModal = () => {
    setIsModalOpen(false)
  }

  return (
    <section className="card">
      <h1>Continuing Module</h1>
      <p>Manage continuing students and subject loads.</p>

      {error && <p className="error-text">{error}</p>}
      {success && <p className="success-text">{success}</p>}

      <div className="enroll-actions">
        <button type="button" onClick={openModal} style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
          <ContinuingIcon /> Process Continuing Student
        </button>
      </div>

      <h2 className="section-title">Search Existing Student</h2>
      <form className="form-grid" onSubmit={searchStudent}>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
          <span
            style={{
              position: 'absolute',
              left: '10px',
              cursor: searchId ? 'pointer' : 'default',
              userSelect: 'none',
            }}
            onClick={() => searchId && setSearchId('')}
          >
            {searchId ? '✕' : '🔍'}
          </span>
          <input
            placeholder="Student ID"
            value={searchId}
            onChange={(e) => setSearchId(e.target.value)}
            required
            style={{ paddingLeft: '30px', width: '100%' }}
          />
        </div>
        <button type="submit" style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
          <SearchIcon /> Search
        </button>
      </form>

      <h2 className="section-title">Student List</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Name</th>
              <th>Program</th>
              <th>Semester</th>
              <th>Year Level</th>
              <th>Section</th>
              <th>Academic Year</th>
              <th>Gender</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {allStudents.slice(0, 10).map((s) => (
              <tr key={s.id}>
                <td>{s.student_id}</td>
                <td>{s.last_name}, {s.first_name} {s.middle_name || ''}.</td>
                <td>{programs.find((p) => p.id === s.program)?.name || '-'}</td>
                <td>{s.semester || '-'}</td>
                <td>{s.year_level}</td>
                <td>{sections.find((sec) => sec.id === s.section)?.name || '-'}</td>
                <td>{s.academic_year || '-'}</td>
                <td>-</td>
                <td>
                  <button type="button" onClick={() => { openModal(); setSearchId(s.student_id); }}>
                    Select
                  </button>
                  <button type="button" onClick={() => { setSearchId(s.student_id); }}>
                    Edit
                  </button>
                  <button type="button" onClick={() => { /* TODO: Implement delete functionality */ }}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
            {allStudents.length === 0 && <tr><td colSpan={9}>No continuing students found.</td></tr>}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="enroll-modal-overlay" onClick={closeModal}>
          <div className="enroll-modal" style={{ overflowY: 'auto', maxHeight: '90vh' }} onClick={(e) => e.stopPropagation()}>
            <div className="enroll-modal-header">
              <h2>Continuing Student Form</h2>
              <button type="button" onClick={closeModal}>
                Close
              </button>
            </div>

            <div className="enroll-sheet-form">
              <div className="sheet-section-title">Search Student</div>
              <form onSubmit={searchStudent} style={{ display: 'flex', gap: '10px', alignItems: 'center', marginBottom: '1rem' }}>
                <div style={{ position: 'relative', flex: 1 }}>
                  <input
                    list="student-list"
                    placeholder="Search or Select Student ID"
                    value={searchId}
                    onChange={(e) => setSearchId(e.target.value)}
                    required
                    style={{ width: '100%' }}
                  />
                  <datalist id="student-list">
                    {allStudents.map((s) => (
                      <option key={s.id} value={s.student_id}>
                        {s.last_name}, {s.first_name} {s.middle_name || ''}.
                      </option>
                    ))}
                  </datalist>
                </div>
                <button type="submit" style={{ display: 'inline-flex', alignItems: 'center', gap: '5px', whiteSpace: 'nowrap' }}>
                  <SearchIcon /> Load
                </button>
              </form>

              {student && (
                <>
                  <div className="sheet-section-title">Student Details</div>
                  <div className="sheet-grid">
                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>Name</span>
                      <div className="readonly-field" style={{ flex: 1 }}>{`${student.last_name}, ${student.first_name} ${student.middle_name || ''}.`}</div>
                    </div>
                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>Student ID</span>
                      <div className="readonly-field" style={{ flex: 1 }}>{student.student_id}</div>
                    </div>
                    <div className="field-inline-label" style={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>Current Program</span>
                      <div className="readonly-field" style={{ flex: 1 }}>{selectedProgramData ? selectedProgramData.name : '-'}</div>
                    </div>
                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>Current Year</span>
                      <div className="readonly-field" style={{ flex: 1 }}>{student.year_level}</div>
                    </div>
                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span>Current Semester</span>
                      <div className="readonly-field" style={{ flex: 1 }}>{student.semester || '-'}</div>
                    </div>
                  </div>

                  <div className="sheet-section-title">Schedule Basis Selection</div>
                  <div className="sheet-grid" style={{ display: 'flex', gap: '16px', alignItems: 'center', flexWrap: 'wrap' }}>
                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: '250px' }}>
                      <span style={{ minWidth: '120px' }}>Target Program</span>
                      <select value={selectedProgram} onChange={(e) => setSelectedProgram(e.target.value)} style={{ flex: 1 }}>
                        <option value="">Select Program</option>
                        {programs.map((program) => (
                          <option key={program.id} value={program.id}>
                            {program.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: '200px' }}>
                      <span style={{ minWidth: '120px' }}>Target Year Level</span>
                      <select value={selectedYearLevel} onChange={(e) => setSelectedYearLevel(e.target.value)} style={{ flex: 1 }}>
                        <option value="1">Year 1</option>
                        <option value="2">Year 2</option>
                        <option value="3">Year 3</option>
                        <option value="4">Year 4</option>
                      </select>
                    </div>

                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: '200px' }}>
                      <span style={{ minWidth: '120px' }}>Target Academic Year</span>
                      <select value={selectedAcademicYear} onChange={(e) => setSelectedAcademicYear(e.target.value)} style={{ flex: 1 }}>
                        <option value="">Select Academic Year</option>
                        {academicYearOptions.map((yearLabel) => (
                          <option key={yearLabel} value={yearLabel}>
                            {yearLabel}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: '200px' }}>
                      <span style={{ minWidth: '120px' }}>Target Semester</span>
                      <select value={selectedSemester} onChange={(e) => setSelectedSemester(e.target.value)} style={{ flex: 1 }}>
                        <option value="1">1st Semester</option>
                        <option value="2">2nd Semester</option>
                        <option value="3">Summer</option>
                      </select>
                    </div>

                    <div className="field-inline-label" style={{ display: 'flex', alignItems: 'center', gap: '8px', minWidth: '200px' }}>
                      <span style={{ minWidth: '120px' }}>Target Section</span>
                      <select value={selectedSection} onChange={(e) => setSelectedSection(e.target.value)} style={{ flex: 1 }}>
                        <option value="">Select Section</option>
                        {filteredSections.map((section) => (
                          <option key={section.id} value={section.id}>
                            {section.name} (Year {section.year_level}, Sem {section.semester})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="sheet-section-title">Subject Load Schedule</div>
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Subject Code</th>
                          <th>Subject Title</th>
                        </tr>
                      </thead>
                      <tbody>
                        {scheduleRows.map((row, index) => (
                          <tr key={`${row.code}-${index}`}>
                            <td>{row.code}</td>
                            <td>{row.title}</td>
                          </tr>
                        ))}
                        {!scheduleRows.length && (
                          <tr>
                            <td colSpan={2}>No schedule found.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </div>

            {student && (
              <div className="enroll-modal-footer">
                <button type="button" onClick={saveChanges}>
                  Save Changes
                </button>
                <button type="button" onClick={promoteStudent}>
                  Promote Student
                </button>
                <button type="button" onClick={approveAndFinalizeSchedule}>
                  Approve & Finalize
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  )
}
